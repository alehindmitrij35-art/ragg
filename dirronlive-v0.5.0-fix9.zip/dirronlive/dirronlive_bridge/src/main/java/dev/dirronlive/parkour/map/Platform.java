package dev.dirronlive.parkour.map;

/**
 * Платформа маршрута (абсолютные координаты). Верхний блок — на высоте
 * {@code y}, игрок стоит на {@code y + 1}.
 */
public record Platform(int index, int x0, int z0, int x1, int z1, int y, Kind kind) {

    public enum Kind { START, NORMAL, FIRST, RUNWAY, BOUNCE, BEAM, FINISH }

    public double centerX() {
        return (x0 + x1 + 1) / 2.0;
    }

    public double centerZ() {
        return (z0 + z1 + 1) / 2.0;
    }

    public boolean contains(double x, double z) {
        return x >= x0 && x < x1 + 1 && z >= z0 && z < z1 + 1;
    }

    /** Сколько воздуха между краями платформ по горизонтали (в блоках). */
    public double airGapTo(Platform other) {
        int dx = Math.max(0, Math.max(other.x0 - x1, x0 - other.x1) - 1);
        int dz = Math.max(0, Math.max(other.z0 - z1, z0 - other.z1) - 1);
        return Math.sqrt(dx * dx + dz * dz);
    }
}
