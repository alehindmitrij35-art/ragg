package dev.dirronlive.parkour.world;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Очередь действий за подарки: одна штука подарка = одно срабатывание.
 *
 * <p>Программа присылает для записи истории (ID) нарастающее «всего»:
 * ×1 → ×2 → … → ×1000. Очередь принимает только прирост, поэтому повтор
 * того же события ничего не добавляет. Действия выполняются по тикам
 * сервера порциями, игра остаётся отзывчивой; толчки идут по одному с
 * паузой, чтобы каждый был отдельным импульсом.
 */
public final class ActionQueue {
    /** Сколько завершённых заданий помнить (для защиты от повторов). */
    static final int REMEMBER = 4000;
    /** Как часто отправлять прогресс, тиков. */
    static final int REPORT_EVERY = 10;

    public record Progress(int accepted, int done, int queued, int ok, String result, int room, boolean finished) {}

    public static final class Job {
        public final String id;
        public final String action;
        public final Map<String, Object> params;
        public final String label;
        final UUID player;
        int accepted;
        int done;
        int ok;
        int fromRoom = -1;
        String firstText = "";
        String lastText = "";
        long nextAt;
        long lastReport = Long.MIN_VALUE;
        Consumer<Progress> listener;

        Job(String id, String action, Map<String, Object> params, String label, UUID player) {
            this.id = id;
            this.action = action;
            this.params = params;
            this.label = label;
            this.player = player;
        }

        public int accepted() {
            return accepted;
        }

        public int done() {
            return done;
        }
    }

    private final ParkourWorld pw;
    private final Map<String, Job> jobs = new LinkedHashMap<>(64, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Job> eldest) {
            return size() > REMEMBER && eldest.getValue().done >= eldest.getValue().accepted;
        }
    };
    private final Deque<Job> pending = new ArrayDeque<>();

    ActionQueue(ParkourWorld pw) {
        this.pw = pw;
    }

    /**
     * Принять «всего {@code total} штук» для задания {@code id}. Возвращает
     * задание (с уже принятым количеством). Повтор с тем же или меньшим
     * {@code total} ничего не добавляет.
     */
    public Job submit(ServerPlayerEntity player, String id, String action, Map<String, Object> params,
                      String label, int total, Consumer<Progress> listener) {
        Job job = jobs.get(id);
        if (job == null) {
            job = new Job(id, action, params, label, player.getUuid());
            jobs.put(id, job);
        }
        if (listener != null) job.listener = listener;
        int wanted = Math.max(1, total);
        boolean wasIdle = job.done >= job.accepted;
        if (wanted > job.accepted) {
            job.accepted = wanted;
            if (wasIdle && !pending.contains(job)) pending.addLast(job);
        }
        report(job, true);
        return job;
    }

    public Job job(String id) {
        return jobs.get(id);
    }

    /** Сколько штук ждёт выполнения во всех заданиях. */
    public int queued() {
        int sum = 0;
        for (Job job : pending) sum += job.accepted - job.done;
        return sum;
    }

    public void clear() {
        pending.clear();
    }

    /** Тик сервера: выполнить очередную порцию. */
    void tick(long now) {
        int budget = 400; // общий предел срабатываний за тик
        int rounds = pending.size();
        while (budget > 0 && rounds-- > 0 && !pending.isEmpty()) {
            Job job = pending.pollFirst();
            if (now < job.nextAt) {
                pending.addLast(job);
                continue;
            }
            ServerPlayerEntity player = pw.server.getPlayerManager().getPlayer(job.player);
            if (player == null) {
                pending.addLast(job); // игрок вернётся — продолжим
                continue;
            }
            int perTick = perTick(job.action);
            int spacing = spacing(job.action);
            int n = Math.min(Math.min(perTick, budget), job.accepted - job.done);
            for (int i = 0; i < n; i++) runOne(job, player);
            budget -= n;
            job.nextAt = now + spacing;
            report(job, job.done >= job.accepted);
            if (job.done < job.accepted) pending.addLast(job);
        }
    }

    private void runOne(Job job, ServerPlayerEntity player) {
        PlayerProgress p = pw.progress(player);
        if (job.fromRoom < 0) job.fromRoom = p.room;
        boolean first = job.done == 0;
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, job.action, job.params, job.label, !first);
        job.done++;
        if (o.ok()) job.ok++;
        if (first) job.firstText = o.text();
        job.lastText = o.text();
        if (!first && job.accepted > 1 && (job.done % 10 == 0 || job.done == job.accepted)) {
            String title = ParkourActions.TITLES.getOrDefault(job.action, job.action);
            pw.actionbar(player, Text.literal(title + " · " + job.done + " из " + job.accepted)
                    .formatted(Formatting.LIGHT_PURPLE));
        }
    }

    private void report(Job job, boolean force) {
        Consumer<Progress> l = job.listener;
        if (l == null) return;
        long now = pw.now();
        if (!force && now - job.lastReport < REPORT_EVERY) return;
        job.lastReport = now;
        ServerPlayerEntity player = pw.server.getPlayerManager().getPlayer(job.player);
        int room = player != null && pw.state.built ? pw.progress(player).room : 0;
        int queued = job.accepted - job.done;
        l.accept(new Progress(job.accepted, job.done, queued, job.ok, summary(job, room), room, queued == 0));
    }

    private static final Pattern ROOM = Pattern.compile("^(.*?)Комната (\\d+) → (\\d+)$");

    /** «Комната 12 → 7», «Толчок вправо ×1000», «Выполнено 237 из 1000». */
    public static String summary(Job job, int room) {
        if (job.done == 0) return job.accepted > 1 ? "В очереди " + job.accepted : "В очереди";
        Matcher first = ROOM.matcher(job.firstText);
        Matcher last = ROOM.matcher(job.lastText);
        if (first.matches() && last.matches()) {
            String text = first.group(1) + "Комната " + first.group(2) + " → " + last.group(3);
            return job.done > 1 ? text + " (×" + job.done + ")" : text;
        }
        if (job.done == 1) return job.lastText;
        String base = job.lastText.replaceAll(": зарядов \\d+$", "").replaceAll(" на \\d+ с$", "");
        return base + " ×" + job.done;
    }

    static int perTick(String action) {
        return switch (action) {
            case "push", "super_push", "trampoline", "vanishing_step", "personal_checkpoint" -> 1;
            case "room_forward", "room_back", "big_rollback", "restart_room", "to_first_level",
                 "to_last_level", "goto_room" -> 25;
            default -> 100;
        };
    }

    /** Пауза между порциями, тиков: толчки — отдельными импульсами. */
    static int spacing(String action) {
        return switch (action) {
            case "push" -> 3;
            case "super_push" -> 6;
            case "trampoline" -> 10;
            case "vanishing_step" -> 30;
            default -> 1;
        };
    }
}
