package dev.dirronlive.parkour.map;

/**
 * Где на карте стоит каждая комната. Комнаты 10 × 10: строка — тема,
 * столбец — номер внутри десятка. Между комнатами — пустота.
 */
public final class ParkourLayout {
    public static final int ROOMS = 100;
    public static final int SPACING = 140;

    private ParkourLayout() {}

    public static int originX(int baseX, int room) {
        return baseX + ((room - 1) % 10) * SPACING;
    }

    public static int originZ(int baseZ, int room) {
        return baseZ + ((room - 1) / 10) * SPACING;
    }

    public static RoomPlan plan(int baseX, int baseY, int baseZ, int room) {
        return RoomGenerator.generate(room, originX(baseX, room), baseY, originZ(baseZ, room));
    }
}
