﻿# Кладёт рядом с dirronlive.exe коннектор TikTok LIVE:
#   Release\tiktok\node.exe        — Node.js (с машины сборки, 20+)
#   Release\tiktok\connector.mjs    — коннектор Dirronlive
#   Release\tiktok\node_modules\…   — tiktok-live-connector и зависимости
# Затем запускает тесты коннектора и самопроверку настоящей библиотеки.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$release = Join-Path $root 'build\windows\x64\runner\Release'
$source = Join-Path $root 'tiktok_connector'
$dest = Join-Path $release 'tiktok'

$node = (Get-Command node -ErrorAction Stop).Source
$version = (& $node --version).Trim()
Write-Host "Node.js $version ($node)"
if ([int]($version.TrimStart('v').Split('.')[0]) -lt 20) {
    Write-Host "::error title=tiktok::нужен Node.js 20+, найден $version"
    exit 1
}

# Тесты коннектора на поддельной библиотеке (без сети).
& $node --test (Join-Path $source 'test\connector.test.mjs')
if ($LASTEXITCODE -ne 0) { Write-Host "::error title=tiktok::тесты коннектора не прошли"; exit 1 }
Write-Host "::notice title=tiktok::тесты коннектора прошли"

if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
New-Item -ItemType Directory -Path $dest | Out-Null
Copy-Item $node (Join-Path $dest 'node.exe')
$nodeLicense = Join-Path (Split-Path $node) 'LICENSE'
if (Test-Path $nodeLicense) { Copy-Item $nodeLicense (Join-Path $dest 'NODE_LICENSE.txt') }
foreach ($f in 'package.json', 'connector.mjs', 'lib.mjs') {
    Copy-Item (Join-Path $source $f) $dest
}

Push-Location $dest
try {
    & npm install --omit=dev --no-audit --no-fund --loglevel=error
    if ($LASTEXITCODE -ne 0) { Write-Host "::error title=tiktok::npm install не удался"; exit 1 }
} finally {
    Pop-Location
}

# Самопроверка: в установленной библиотеке есть всё, что использует коннектор.
$check = & (Join-Path $dest 'node.exe') (Join-Path $dest 'connector.mjs') --self-check
Write-Host $check
if ($LASTEXITCODE -ne 0) { Write-Host "::error title=tiktok::самопроверка tiktok-live-connector: $check"; exit 1 }
$size = [math]::Round(((Get-ChildItem $dest -Recurse | Measure-Object Length -Sum).Sum / 1MB), 1)
Write-Host "::notice title=tiktok::коннектор готов ($size МБ): $check"

# Полный список подарков TikTok на момент сборки (webcast/gift/list, без эфира):
# программа покажет его сразу после установки, а при запуске обновит со своего
# компьютера (регион и цены — как у стримера). Без сети при сборке — не ошибка.
$snapshot = Join-Path $dest 'gifts-snapshot.json'
$lines = & (Join-Path $dest 'node.exe') (Join-Path $dest 'connector.mjs') --fetch-gifts --lang ru-RU
$giftsLine = $lines | Where-Object { $_ -like '{"type":"gifts"*' } | Select-Object -First 1
if ($giftsLine) {
    $parsed = $giftsLine | ConvertFrom-Json
    $json = @{ version = 1; fetchedAt = (Get-Date).ToUniversalTime().ToString('o'); source = 'snapshot';
               gifts = $parsed.gifts } | ConvertTo-Json -Depth 5 -Compress
    [IO.File]::WriteAllText($snapshot, $json, (New-Object Text.UTF8Encoding($false)))
    Write-Host "::notice title=gifts::в установщике полный список подарков TikTok: $($parsed.gifts.Count)"
} else {
    Write-Host "::warning title=gifts::список подарков при сборке не получен ($lines) — программа скачает его при запуске"
}
