﻿# Dirronlive — подготовка проекта к сборке под Windows.
# Запуск из корня проекта:
#   powershell -ExecutionPolicy Bypass -File .\tools\setup_windows.ps1

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Step([string]$text) {
    Write-Host ""
    Write-Host "==> $text" -ForegroundColor Magenta
}

Step 'Проверка Flutter'
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    Write-Host 'Flutter не найден в PATH. Установите Flutter SDK (см. README.md, шаг 1).' -ForegroundColor Red
    exit 1
}
flutter --version
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if ($root -match '[^\x00-\x7F]') {
    Write-Host "Внимание: в пути к проекту есть кириллица или другие не-латинские символы:" -ForegroundColor Yellow
    Write-Host "  $root" -ForegroundColor Yellow
    Write-Host "Если сборка упадёт с ошибкой CMake/MSBuild, перенесите проект в C:\dev\dirronlive." -ForegroundColor Yellow
}

Step 'Включение сборки для Windows'
flutter config --enable-windows-desktop
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if (-not (Test-Path 'windows\runner\main.cpp')) {
    Step 'Создание Windows-части проекта (flutter create)'
    # Существующие файлы (lib\, test\, pubspec.yaml, README.md) не перезаписываются.
    flutter create --platforms=windows --org com.dirron --project-name dirronlive .
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} else {
    Step 'Windows-часть проекта уже есть, пропускаю flutter create'
}

Step 'Заголовок окна «Dirronlive» и стартовый размер 1280×800'
$mainCpp = (Resolve-Path 'windows\runner\main.cpp').Path
$code = [System.IO.File]::ReadAllText($mainCpp)
$code = $code.Replace('L"dirronlive"', 'L"Dirronlive"')
$code = [regex]::Replace($code, 'Win32Window::Size size\(\d+,\s*\d+\);', 'Win32Window::Size size(1280, 800);')
[System.IO.File]::WriteAllText($mainCpp, $code, (New-Object System.Text.UTF8Encoding($false)))

Step 'Иконка приложения Windows (assets\icon\app_icon.ico)'
# Флаттер-раннер берёт иконку exe, панели задач и заголовка окна из этого файла.
$iconSrc = Join-Path $root 'assets\icon\app_icon.ico'
$iconDst = Join-Path $root 'windows\runner\resources\app_icon.ico'
if (-not (Test-Path $iconSrc)) {
    Write-Host "Не найден $iconSrc" -ForegroundColor Red
    exit 1
}
Copy-Item $iconSrc $iconDst -Force

Step 'Установка зависимостей (flutter pub get)'
flutter pub get
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host ""
Write-Host 'Готово. Дальше по README.md:' -ForegroundColor Green
Write-Host '  flutter analyze'
Write-Host '  flutter test'
Write-Host '  flutter run -d windows'
Write-Host '  flutter build windows --release'
