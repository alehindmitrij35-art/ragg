// Связь с игрой по настоящему WebSocket: вместо Minecraft к серверу
// подключается «поддельный мод», который говорит тем же протоколом.
// В этом файле нет testWidgets — сеть работает по-настоящему.

import 'dart:io';

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/tiktok/tiktok_controller.dart';
import 'package:dirronlive/features/tiktok/tiktok_state.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/events/test_gift.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_mod.dart';
import 'support/memory_store.dart';

const ackTimeout = Duration(milliseconds: 400);

class Harness {
  Harness._(this.container, this.store);

  static Future<Harness> start({
    MemoryJsonStore? store,
    int port = 0,
    bool startLink = true,
  }) async {
    final memory = store ?? MemoryJsonStore();
    final container = createAppContainer(
      await loadInitialData(memory),
      overrides: [
        minecraftLinkConfigProvider.overrideWithValue(MinecraftLinkConfig(
          port: port,
          ackTimeout: ackTimeout,
          pingInterval: const Duration(seconds: 1),
        )),
      ],
    );
    final harness = Harness._(container, memory);
    if (startLink) await harness.link.start();
    return harness;
  }

  final ProviderContainer container;
  final MemoryJsonStore store;

  MinecraftLinkController get link =>
      container.read(minecraftLinkProvider.notifier);
  MinecraftLinkState get state => container.read(minecraftLinkProvider);
  int get port => state.port!;

  GiftEvent sendTestGift() => container.read(testGiftSenderProvider).send();

  /// Шаг комбо, как его пришлёт TikTok Connector: общий comboId,
  /// накопленный счётчик.
  void comboStep(String comboId, int count, {bool active = true}) =>
      container.read(eventBusProvider).publish(GiftEvent(
            id: generateEventId(),
            createdAt: DateTime.now(),
            source: EventSource.test,
            viewerName: 'Тестовый зритель',
            giftName: 'Роза',
            count: count,
            comboId: comboId,
            comboActive: active,
          ));

  GiftEvent comboRecord(String comboId) =>
      container.read(eventLogProvider).byComboId(comboId)!;

  DeliveryStatus delivery(String id) =>
      container.read(eventLogProvider).byId(id)!.delivery;

  Future<FakeMod> connectMod({bool worldReady = false}) async {
    final mod = await FakeMod.connect(port);
    await waitFor(() => state.modConnected, reason: 'мод подключён');
    mod.hello(worldReady: worldReady);
    await waitFor(
      () =>
          state.modVersion != null &&
          state.phase ==
              (worldReady ? LinkPhase.worldReady : LinkPhase.modConnected),
      reason: 'hello обработан',
    );
    return mod;
  }

  Future<void> dispose() async {
    await link.stop();
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();
  }
}

void main() {
  test('выключено → ожидание мода → мод в меню → мир готов → меню', () async {
    final h = await Harness.start(startLink: false);
    expect(h.state.phase, LinkPhase.off);
    expect(h.state.label, 'Связь выключена');

    await h.link.start();
    expect(h.state.phase, LinkPhase.waitingForMod);
    expect(h.state.label, 'Ожидание мода');
    expect(h.port, greaterThan(0));

    final mod = await h.connectMod(worldReady: false);
    expect(h.state.label, 'Мод подключён • открой одиночный мир');
    expect(h.state.modVersion, '1.0.0');
    expect(h.state.minecraftVersion, '1.21.1');
    expect(mod.messages.first['type'], 'welcome');

    mod.world(true);
    await waitFor(() => h.state.phase == LinkPhase.worldReady);
    expect(h.state.label, 'Мир готов');

    mod.world(false);
    await waitFor(() => h.state.phase == LinkPhase.modConnected);

    // Игру закрыли — связь включена, ждём мод снова.
    await mod.close();
    await waitFor(() => h.state.phase == LinkPhase.waitingForMod);

    // Игру открыли снова — мод переподключился.
    final again = await h.connectMod(worldReady: true);
    expect(h.state.phase, LinkPhase.worldReady);

    // TikTok всё это время отдельно и «Не подключено».
    expect(h.container.read(tiktokProvider).phase, TikTokPhase.off);

    await h.dispose();
    await waitFor(() => again.closed, reason: 'мод отключён при выключении');
  });

  test('подарок в готовый мир: «Отправляется» → «Доставлено в игру»', () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);

    final gift = h.sendTestGift();
    await waitFor(() => mod.gifts.isNotEmpty, reason: 'мод получил подарок');
    expect(h.delivery(gift.id), DeliveryStatus.sending);
    expect(mod.gifts.single, {
      'type': 'gift',
      'id': gift.id,
      'viewerName': 'Тестовый зритель',
      'giftName': 'Роза',
      'count': 1,
    });

    mod.ack(gift.id);
    await waitFor(() => h.delivery(gift.id) == DeliveryStatus.delivered);

    // Статус сохранён на диск в той же записи.
    await h.container.read(eventLogProvider.notifier).flush();
    final reloaded = await loadInitialData(h.store);
    expect(reloaded.history.single.id, gift.id);
    expect(reloaded.history.single.delivery, DeliveryStatus.delivered);
    await h.dispose();
  });

  test('три быстрых нажатия — три ID, у каждого своё подтверждение', () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);

    final gifts = [h.sendTestGift(), h.sendTestGift(), h.sendTestGift()];
    await waitFor(() => mod.gifts.length == 3);
    expect(mod.gifts.map((m) => m['id']).toSet(),
        gifts.map((g) => g.id).toSet());

    for (final gift in gifts.reversed) {
      mod.ack(gift.id);
    }
    await waitFor(() =>
        gifts.every((g) => h.delivery(g.id) == DeliveryStatus.delivered));
    expect(h.container.read(eventLogProvider).events.length, 3);
    await h.dispose();
  });

  test('нет ответа 5 секунд → «не подтверждена», позднее ack исправляет',
      () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);

    final gift = h.sendTestGift();
    await waitFor(() => mod.gifts.isNotEmpty);
    expect(h.delivery(gift.id), DeliveryStatus.sending);

    await Future<void>.delayed(ackTimeout + const Duration(milliseconds: 200));
    expect(h.delivery(gift.id), DeliveryStatus.unconfirmed);

    mod.ack(gift.id);
    await waitFor(() => h.delivery(gift.id) == DeliveryStatus.delivered,
        reason: 'позднее подтверждение');
    expect(h.container.read(eventLogProvider).events.length, 1);
    await h.dispose();
  });

  test('повторное подтверждение того же ID ничего не ломает', () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);
    final gift = h.sendTestGift();
    await waitFor(() => mod.gifts.isNotEmpty);
    mod
      ..ack(gift.id)
      ..ack(gift.id);
    await waitFor(() => h.delivery(gift.id) == DeliveryStatus.delivered);
    await Future<void>.delayed(const Duration(milliseconds: 100));
    expect(h.container.read(eventLogProvider).events.length, 1);
    expect(h.delivery(gift.id), DeliveryStatus.delivered);
    await h.dispose();
  });

  test('мир закрыт → «Только в журнале»; при входе старое не отправляется',
      () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);

    mod.world(false); // вышел в главное меню
    await waitFor(() => h.state.phase == LinkPhase.modConnected);
    final offline = h.sendTestGift();
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(h.delivery(offline.id), DeliveryStatus.logOnly);
    expect(mod.gifts, isEmpty);

    mod.world(true); // вернулся в мир
    await waitFor(() => h.state.phase == LinkPhase.worldReady);
    await Future<void>.delayed(const Duration(milliseconds: 300));
    expect(mod.gifts, isEmpty, reason: 'старый подарок не всплывает');
    expect(h.delivery(offline.id), DeliveryStatus.logOnly);

    final online = h.sendTestGift();
    await waitFor(() => mod.gifts.length == 1);
    expect(mod.gifts.single['id'], online.id);
    await h.dispose();
  });

  test('серия 1…5: одна запись «Роза ×5», в игру — один раз в конце', () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);

    for (var count = 1; count <= 5; count++) {
      h.comboStep('streak-1', count);
    }
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(mod.gifts, isEmpty, reason: 'пока серия идёт, в игру ничего не уходит');
    expect(h.comboRecord('streak-1').count, 5);
    expect(h.comboRecord('streak-1').comboActive, isTrue);

    h.comboStep('streak-1', 5, active: false); // конец серии
    await waitFor(() => mod.gifts.length == 1, reason: 'серия ушла в игру');
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(mod.gifts.length, 1);
    expect(mod.gifts.single['count'], 5);
    expect(mod.gifts.single['comboTotal'], 5);
    expect(h.container.read(eventLogProvider).events.length, 1);
    expect(h.comboRecord('streak-1').giftText, 'Роза ×5');

    mod.ack(mod.gifts.single['id']! as String);
    await waitFor(() =>
        h.comboRecord('streak-1').delivery == DeliveryStatus.delivered);
    expect(h.comboRecord('streak-1').deliveredCount, 5);
    await h.dispose();
  });

  test('серия: запоздавшие шаги после конца не отправляются повторно',
      () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);
    h.comboStep('late', 1);
    h.comboStep('late', 3, active: false);
    await waitFor(() => mod.gifts.length == 1);
    h.comboStep('late', 2);
    h.comboStep('late', 3, active: false);
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(mod.gifts.length, 1);
    expect(mod.gifts.single['count'], 3);
    await h.dispose();
  });

  test('серия закончилась, пока мир закрыт → «Только в журнале», '
      'после входа не всплывает', () async {
    final h = await Harness.start();
    final mod = await h.connectMod(worldReady: true);
    h.comboStep('closed', 1);
    h.comboStep('closed', 2);
    mod.world(false); // вышел в меню посреди серии
    await waitFor(() => h.state.phase == LinkPhase.modConnected);
    h.comboStep('closed', 4, active: false);
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(h.comboRecord('closed').delivery, DeliveryStatus.logOnly);

    mod.world(true);
    await waitFor(() => h.state.phase == LinkPhase.worldReady);
    await Future<void>.delayed(const Duration(milliseconds: 300));
    expect(mod.gifts, isEmpty);
    await h.dispose();
  });

  test('связь выключена → «Только в журнале»', () async {
    final h = await Harness.start(startLink: false);
    final gift = h.sendTestGift();
    await Future<void>.delayed(const Duration(milliseconds: 50));
    expect(h.delivery(gift.id), DeliveryStatus.logOnly);
    await h.dispose();
  });

  test('порт занят: ошибка, после освобождения «Повторить» работает',
      () async {
    final blocker = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = blocker.port;
    final h = await Harness.start(port: port);

    expect(h.state.phase, LinkPhase.error);
    expect(h.state.errorMessage, contains('$port'));
    expect(h.state.label, isNot('Связь выключена'));

    await blocker.close();
    await h.link.retry();
    expect(h.state.phase, LinkPhase.waitingForMod);
    expect(h.state.port, port);
    await h.dispose();
  });

  test('выключение освобождает порт', () async {
    final h = await Harness.start();
    final port = h.port;
    await h.link.stop();
    expect(h.state.phase, LinkPhase.off);
    final probe = await ServerSocket.bind(InternetAddress.loopbackIPv4, port);
    await probe.close();
    await h.dispose();
  });

  test('включённая связь запоминается и поднимается при следующем запуске',
      () async {
    final store = MemoryJsonStore();
    var h = await Harness.start(store: store, startLink: false);
    final error = await h.container
        .read(minecraftLinkSwitchProvider)
        .setEnabled(true);
    expect(error, isNull);
    expect(h.container.read(settingsProvider).minecraftLinkEnabled, isTrue);
    expect(h.state.phase, LinkPhase.waitingForMod);
    await h.dispose();

    // «Перезапуск программы»: сервер поднимается сам.
    h = await Harness.start(store: store, startLink: false);
    await waitFor(() => h.state.phase == LinkPhase.waitingForMod,
        reason: 'автозапуск связи');
    await h.dispose();
  });

  test('сервер слушает только 127.0.0.1 и отвечает обычному браузеру',
      () async {
    final h = await Harness.start();
    final client = HttpClient();
    final request =
        await client.getUrl(Uri.parse('http://127.0.0.1:${h.port}/'));
    final response = await request.close();
    expect(response.statusCode, HttpStatus.upgradeRequired);
    await response.drain<void>();
    client.close(force: true);
    expect(h.state.phase, LinkPhase.waitingForMod);
    await h.dispose();
  });
}
