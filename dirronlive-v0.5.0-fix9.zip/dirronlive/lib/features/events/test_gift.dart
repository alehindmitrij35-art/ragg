import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/event_bus.dart';
import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';
import '../../core/providers.dart';

/// Создаёт тестовый подарок и отправляет его в общую шину событий —
/// тем же путём, которым позже пойдут реальные подарки из TikTok LIVE.
class TestGiftSender {
  TestGiftSender(this._bus, this._clock);

  static const viewerName = 'Тестовый зритель';
  static const giftName = 'Роза';
  static const count = 1;

  final EventBus _bus;
  final DateTime Function() _clock;

  /// Одно нажатие — ровно одно новое событие с собственным id.
  GiftEvent send() {
    final event = GiftEvent(
      id: generateEventId(),
      createdAt: _clock(),
      source: EventSource.test,
      viewerName: viewerName,
      giftName: giftName,
      count: count,
    );
    _bus.publish(event);
    return event;
  }
}

final testGiftSenderProvider = Provider<TestGiftSender>(
  (ref) => TestGiftSender(ref.watch(eventBusProvider), ref.watch(clockProvider)),
);

/// «Тестовое комбо»: имитирует, как зритель TikTok много раз подряд жмёт
/// «Розу». В шину уходит серия событий с общим comboId и растущим
/// счётчиком (1, 2, … [steps]) с паузой [interval]; последнее событие
/// завершает серию. Состояние — идёт ли сейчас комбо и текущий счётчик.
class TestComboState {
  const TestComboState({this.running = false, this.count = 0});

  final bool running;
  final int count;
}

class TestComboController extends Notifier<TestComboState> {
  static const steps = 10;
  static const interval = Duration(milliseconds: 300);

  Timer? _timer;

  @override
  TestComboState build() {
    ref.onDispose(() => _timer?.cancel());
    return const TestComboState();
  }

  /// Запускает серию. Пока она идёт, повторный вызов ничего не делает.
  void start() {
    if (state.running) return;
    final bus = ref.read(eventBusProvider);
    final clock = ref.read(clockProvider);
    final comboId = generateEventId();

    void emit(int count) {
      final last = count >= steps;
      bus.publish(GiftEvent(
        id: generateEventId(),
        createdAt: clock(),
        source: EventSource.test,
        viewerName: TestGiftSender.viewerName,
        giftName: TestGiftSender.giftName,
        count: count,
        comboId: comboId,
        comboActive: !last,
      ));
      state = TestComboState(running: !last, count: count);
    }

    emit(1);
    var count = 1;
    _timer = Timer.periodic(interval, (timer) {
      count++;
      emit(count);
      if (count >= steps) {
        timer.cancel();
        _timer = null;
      }
    });
  }
}

final testComboProvider =
    NotifierProvider<TestComboController, TestComboState>(
        TestComboController.new);
