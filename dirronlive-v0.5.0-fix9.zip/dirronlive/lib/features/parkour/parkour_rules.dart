import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/json_store.dart';
import '../../core/storage/storage_exception.dart';
import '../../core/events/gift_event.dart';
import 'action_catalog.dart';

/// Карточка действия: «подарок → действие».
///
/// Одна штука подарка — одно срабатывание: серия «Роза ×1000» запускает
/// действие ровно 1000 раз, без лимита. Карточка может быть без подарка —
/// тогда она не срабатывает на эфир, но её можно проверить в игре.
/// Лайки и подписка как «подарки» для карточек действий.
const likesTriggerId = 'likes';
const followTriggerId = 'follow';

/// Сколько лайков от одного зрителя дают одно срабатывание.
const likesPerTrigger = 10;

bool isSocialTrigger(String? id) => id == likesTriggerId || id == followTriggerId;

class GiftRule {
  const GiftRule({
    required this.id,
    this.giftName = '',
    this.giftId,
    this.imageUrl,
    required this.actionId,
    this.params = const {},
    this.enabled = true,
  });

  final String id;

  /// Название подарка, как его показывает Dirronlive («Роза»); пусто — не выбран.
  final String giftName;

  /// ID подарка в TikTok. Если `null` — правило ищет подарок по названию.
  final String? giftId;
  final String? imageUrl;
  final String actionId;
  final Map<String, Object> params;
  final bool enabled;

  ParkourAction? get action => parkourActionById(actionId);

  String get actionTitle => action?.title ?? actionId;

  bool get hasGift => giftName.trim().isNotEmpty || giftId != null;

  /// «Роза → Толчок»
  String get bindingText => '${hasGift ? giftName : 'Без подарка'} → $actionTitle';

  bool matches(GiftEvent event) {
    if (!hasGift) return false;
    final id = giftId;
    final eventId = event.giftId;
    if (id != null && eventId != null) return id == eventId;
    return _norm(giftName) == _norm(event.giftName);
  }

  static String _norm(String s) => s.trim().toLowerCase().replaceAll('ё', 'е');

  GiftRule copyWith({
    String? giftName,
    String? giftId,
    bool clearGiftId = false,
    String? imageUrl,
    String? actionId,
    Map<String, Object>? params,
    bool? enabled,
  }) =>
      GiftRule(
        id: id,
        giftName: giftName ?? this.giftName,
        giftId: clearGiftId ? null : (giftId ?? this.giftId),
        imageUrl: clearGiftId ? imageUrl : (imageUrl ?? this.imageUrl),
        actionId: actionId ?? this.actionId,
        params: params ?? this.params,
        enabled: enabled ?? this.enabled,
      );

  Map<String, Object?> toJson() => {
        'id': id,
        'giftName': giftName,
        if (giftId != null) 'giftId': giftId,
        if (imageUrl != null) 'imageUrl': imageUrl,
        'actionId': actionId,
        'params': params,
        'enabled': enabled,
      };

  static GiftRule? fromJson(Object? json) {
    if (json is! Map) return null;
    final id = json['id'];
    final giftName = json['giftName'];
    final actionId = json['actionId'];
    if (id is! String || actionId is! String) return null;
    final action = parkourActionById(actionId);
    if (action == null) return null;
    final rawParams = json['params'];
    final params = action.normalize(
        rawParams is Map ? rawParams.cast<String, Object?>() : const {});
    final giftId = json['giftId'];
    final imageUrl = json['imageUrl'];
    return GiftRule(
      id: id,
      giftName: giftName is String ? giftName : '',
      giftId: giftId is String && giftId.isNotEmpty ? giftId : null,
      imageUrl: imageUrl is String && imageUrl.isNotEmpty ? imageUrl : null,
      actionId: actionId,
      params: params,
      enabled: json['enabled'] != false,
    );
  }
}

class ParkourRulesState {
  const ParkourRulesState({
    this.rules = const [],
    this.modeActive = true,
    this.saveError,
  });

  final List<GiftRule> rules;

  /// Режим «Паркур» включён: правила срабатывают на подарки эфира.
  final bool modeActive;
  final String? saveError;

  /// Первое включённое правило для подарка.
  GiftRule? ruleFor(GiftEvent event) {
    for (final rule in rules) {
      if (rule.enabled && rule.matches(event)) return rule;
    }
    return null;
  }

  GiftRule? get secondChance {
    for (final rule in rules) {
      if (rule.enabled && rule.actionId == 'second_chance') return rule;
    }
    return null;
  }
}

class ParkourRulesRepository {
  ParkourRulesRepository(this.store);

  static const fileName = 'parkour_rules.json';

  final JsonStore store;

  Future<(ParkourRulesState, List<String>)> load() async {
    Map<String, Object?>? json;
    try {
      json = await store.read(fileName);
    } on StorageException catch (e) {
      return (ParkourRulesState(rules: defaultCards()), ['Правила паркура не загружены. ${e.message}']);
    } on FormatException {
      final backup = await store.quarantine(fileName);
      return (
        ParkourRulesState(rules: defaultCards()),
        [
          'Файл правил паркура повреждён, правила сброшены.'
              '${backup == null ? '' : ' Копия: «$backup».'}'
        ]
      );
    }
    // Новая настройка: четыре готовые карточки, подарки выбирает стример.
    if (json == null) return (ParkourRulesState(rules: defaultCards()), const <String>[]);
    final raw = json['rules'];
    final rules = <GiftRule>[
      if (raw is List)
        for (final item in raw)
          if (GiftRule.fromJson(item) case final GiftRule rule) rule,
    ];
    return (
      // Все карточки удалены — снова показать готовые (подарки выбирает стример).
      ParkourRulesState(rules: rules.isEmpty ? defaultCards() : rules, modeActive: json['modeActive'] != false),
      const <String>[]
    );
  }

  Future<void> save(ParkourRulesState state) => store.write(fileName, {
        'version': 2,
        'modeActive': state.modeActive,
        'rules': [for (final r in state.rules) r.toJson()],
      });
}

/// Готовые карточки для новой настройки.
List<GiftRule> defaultCards() => [
      for (final id in const ['push', 'super_push', 'to_first_level', 'to_last_level'])
        GiftRule(id: 'card-$id', actionId: id, params: parkourActionById(id)!.defaults()),
    ];

/// Правила, прочитанные при запуске (переопределяется в createAppContainer).
final initialParkourRulesProvider =
    Provider<ParkourRulesState>((ref) => const ParkourRulesState());

final parkourRulesProvider =
    NotifierProvider<ParkourRulesController, ParkourRulesState>(
        ParkourRulesController.new);

class ParkourRulesController extends Notifier<ParkourRulesState> {
  Future<void> _pending = Future<void>.value();

  @override
  ParkourRulesState build() => ref.read(initialParkourRulesProvider);

  /// Добавить или заменить правило с тем же id. Возвращает ошибку сохранения.
  Future<String?> upsert(GiftRule rule) {
    final rules = [...state.rules];
    final index = rules.indexWhere((r) => r.id == rule.id);
    if (index >= 0) {
      rules[index] = rule;
    } else {
      rules.add(rule);
    }
    return _set(ParkourRulesState(rules: rules, modeActive: state.modeActive));
  }

  /// Переставить карточку [id] на место [to] (0 — первая). Порядок сохраняется.
  Future<String?> move(String id, int to) {
    final rules = [...state.rules];
    final from = rules.indexWhere((r) => r.id == id);
    if (from < 0) return Future.value(null);
    final rule = rules.removeAt(from);
    rules.insert(to.clamp(0, rules.length).toInt(), rule);
    return _set(ParkourRulesState(rules: rules, modeActive: state.modeActive));
  }

  Future<String?> remove(String id) => _set(ParkourRulesState(
      rules: state.rules.where((r) => r.id != id).toList(),
      modeActive: state.modeActive));

  Future<String?> setEnabled(String id, bool enabled) {
    final rule = state.rules.where((r) => r.id == id).firstOrNull;
    if (rule == null) return Future.value(null);
    return upsert(rule.copyWith(enabled: enabled));
  }

  Future<String?> setModeActive(bool active) =>
      _set(ParkourRulesState(rules: state.rules, modeActive: active));

  /// После сверки каталога: правилам без ID подставляется ID подарка
  /// с тем же названием.
  Future<String?> fillGiftIds(Map<String, ({String id, String? image})> byName) {
    var changed = false;
    final rules = <GiftRule>[];
    for (final r in state.rules) {
      final found = r.giftId == null ? byName[r.giftName.trim().toLowerCase()] : null;
      if (found != null) {
        changed = true;
        rules.add(r.copyWith(giftId: found.id, imageUrl: found.image));
      } else {
        rules.add(r);
      }
    }
    if (!changed) return Future.value(null);
    return _set(ParkourRulesState(rules: rules, modeActive: state.modeActive));
  }

  Future<String?> _set(ParkourRulesState next) {
    state = next;
    final repository = ParkourRulesRepository(ref.read(jsonStoreProvider));
    final done = _pending.then((_) async {
      try {
        await repository.save(state);
        if (state.saveError != null) {
          state = ParkourRulesState(rules: state.rules, modeActive: state.modeActive);
        }
        return null;
      } catch (e) {
        final message = 'Не удалось сохранить правила: ${e is StorageException ? e.message : e}';
        state = ParkourRulesState(
            rules: state.rules, modeActive: state.modeActive, saveError: message);
        return message;
      }
    });
    _pending = done;
    return done;
  }
}

int _ruleSerial = 0;

String newRuleId() =>
    'rule-${DateTime.now().microsecondsSinceEpoch}-${_ruleSerial++}';
