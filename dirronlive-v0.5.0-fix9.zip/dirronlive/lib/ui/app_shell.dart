import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/providers.dart';
import '../features/navigation/app_section.dart';
import 'screens/history_screen.dart';
import 'screens/live_screen.dart';
import 'screens/modes_screen.dart';
import 'screens/overlays_screen.dart';
import 'screens/settings_screen.dart';
import 'top_bar.dart';

/// Верхняя строка навигации и выбранный экран под ней.
class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  @override
  void initState() {
    super.initState();
    // Предупреждения, собранные при загрузке (например, повреждённый файл),
    // показываем после первого кадра, когда ScaffoldMessenger уже готов.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final warnings = ref.read(initialDataProvider).warnings;
      if (warnings.isEmpty) return;
      ref.read(noticeServiceProvider).error(warnings.join('\n'));
    });
  }

  @override
  Widget build(BuildContext context) {
    final section = ref.watch(currentSectionProvider);
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const TopBar(),
          Expanded(
            child: KeyedSubtree(
              key: ValueKey(section),
              child: _screenFor(section),
            ),
          ),
        ],
      ),
    );
  }

  Widget _screenFor(AppSection section) => switch (section) {
        AppSection.live => const LiveScreen(),
        AppSection.modes => const ModesScreen(),
        AppSection.overlays => const OverlaysScreen(),
        AppSection.history => const HistoryScreen(),
        AppSection.settings => const SettingsScreen(),
      };
}
