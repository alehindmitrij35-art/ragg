import 'dart:async';

import 'app_event.dart';

/// Общая шина событий приложения.
///
/// Любой источник (кнопка «Тестовый подарок», будущий TikTok Connector,
/// будущий мост с Fabric-модом) публикует событие сюда, а журнал,
/// игровые режимы и оверлеи подписываются на нужные типы событий.
class EventBus {
  final StreamController<AppEvent> _controller =
      StreamController<AppEvent>.broadcast();

  /// Все события подряд.
  Stream<AppEvent> get stream => _controller.stream;

  /// Только события типа [T].
  Stream<T> on<T extends AppEvent>() =>
      _controller.stream.where((event) => event is T).cast<T>();

  void publish(AppEvent event) {
    if (_controller.isClosed) return;
    _controller.add(event);
  }

  Future<void> dispose() => _controller.close();
}
