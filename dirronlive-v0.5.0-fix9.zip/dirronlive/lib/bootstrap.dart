import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/initial_data.dart';
import 'core/providers.dart';
import 'features/events/event_log.dart';
import 'features/minecraft/gift_delivery.dart';
import 'features/minecraft/minecraft_link.dart';
import 'features/overlays/overlay_settings.dart';
import 'features/overlays/stream_stats.dart';
import 'features/parkour/gift_catalog.dart';
import 'features/parkour/parkour_engine.dart';
import 'features/parkour/parkour_rules.dart';

/// Создаёт контейнер провайдеров приложения.
///
/// Порядок важен: сначала журнал (он первым получает каждое событие из шины),
/// затем доставка в игру (она меняет статус уже записанного события),
/// затем правила паркура (они пишут результат действия в ту же запись).
/// Если в настройках связь с игрой была включена, сервер поднимается сразу.
ProviderContainer createAppContainer(
  InitialData data, {
  List<Override> overrides = const [],
  bool autoStartMinecraftLink = true,
}) {
  final container = ProviderContainer(
    overrides: [
      initialDataProvider.overrideWithValue(data),
      initialParkourRulesProvider.overrideWithValue(data.parkourRules),
      initialGiftCatalogProvider.overrideWithValue(data.giftCatalog),
      initialOverlaySettingsProvider.overrideWithValue(data.overlaySettings),
      initialLiveStatsProvider.overrideWithValue(data.liveStats),
      ...overrides,
    ],
  );
  container.read(eventLogProvider);
  container.read(giftDeliveryProvider);
  container.read(parkourEngineProvider);
  // Статистика для оверлеев — та же обработанная лента событий.
  container.read(streamStatsProvider);
  if (autoStartMinecraftLink && data.settings.minecraftLinkEnabled) {
    unawaited(container.read(minecraftLinkProvider.notifier).start());
  }
  return container;
}
